import sqlite3
conn=sqlite3.connect('Bookstore.db')
c=conn.cursor()#get result


def add():
    print("---ALL INFORMATION PROMPTED IS MANDATORY TO ENTER---")
    title=input("Enter Book Name:")
    genre=input("Enter Genre:")
    quantity=int(input("Enter Quantity:"))
    author=input("Enter Author:")
    publication=input("Enter Publication:")
    price=int(input("Enter Price of Book:"))
    discount=int(input("Enter Discount Amount:"))
    row=c.fetchone()
    if row is not None:
        c.execute("update add_books set quantity=quantity+'" + str(quantity) + "' where bookname='" + title + "'")
        conn.commit()
        print("""++++++++++++++++++++++++SUCCESSFULLY ADDED++++++++++++++++++++++++""")
    else:
        c.execute(
            "insert into add_books(bookname,genre,quantity,author,publication,price,discount) values('" + title + "','" + genre + "','"
            + str(quantity) + "','" + author + "','" + publication + "','" + str(price) + "','" + str(discount) + "')")
        conn.commit()
    print("""++++++++++++++++++++++++SUCCESSFULLY ADDED++++++++++++++++++++++++""")

