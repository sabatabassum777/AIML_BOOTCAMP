import sqlite3
con = sqlite3.connect('Bookstore.db')
c = con.cursor()


def display():
    print("AVAILABLE BOOKS IN THE BOOKSTORE")
    s = c.execute("select * from add_books")
    #f=c.execute("select price from discount_books")
    for v in s:
        print(v)
    #for z in f:
        #print(z)
        #print("this is discount area")

con.commit()
