import mainpack as main
import mainpack.subpack1 as p1
import mainpack.subpack2 as p2
import mainpack.subpack3 as p3
import mainpack.subpack4 as p4
from mainpack.subpack1 import add as a
from mainpack.subpack2 import sell as b
from mainpack.subpack3 import display as c
from mainpack.subpack4 import discount as d
print(main.mainpackdemo())
while True:
    print('''            1.ADD BOOKS
            2. SELL BOOKS
            3. DISPLAY BOOKS
            4. DISCOUNT ON BOOKS 
            5. EXIT ''')
    print("Choose an option from menu")
    ch=int(input("Enter Your Choice:"))
    if ch==1:
        a.add()
    elif ch==2:
        b.sell()
    elif ch==3:
        c.display()
    elif ch==4:
        d.discount()
    elif ch==5:
        print("+++++++++++++THANKYOU FOR VISITING !! KEEP SHOPPING  WITH US+++++++++++++++++")
        break