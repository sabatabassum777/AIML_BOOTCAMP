import sqlite3
conn=sqlite3.connect('Bookstore.db')
query1=''' create table add_books( BOOKNAME text not null,GENRE text not null,QUANTITY int not null,AUTHOR text
not null,PUBLICATION text not null,PRICE int not null,discount int not null )'''
conn.execute(query1)

query2=''' create table sell_books(BOOKNAME text not null ,QUANTITY
int not null , foreign key(BOOKNAME) references add_books(BOOKNAME))'''

query3=''' create view discount_books as select bookname,genre,price from add_books '''
conn.execute(query3)
conn.execute(query2)
conn.execute("update add_books set discount=100 where bookname='java' ")