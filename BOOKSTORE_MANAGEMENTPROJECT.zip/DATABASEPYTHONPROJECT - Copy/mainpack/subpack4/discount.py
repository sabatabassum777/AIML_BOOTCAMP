import sqlite3
conn=sqlite3.connect('Bookstore.db')
c=conn.cursor()

def discount():
    print("++++++++++++++++TODAY'S SALE+++++++++++++++++++++++")
    print("++++++++++++++++KNOW OUR DISCOUNT OFFERS ON BOOKS GENRE!!!+++++++++++++")
    title=input("enter book name:")
    c.execute("select price from add_books where bookname='" + title + "'")
    row=c.fetchone()
    if row is not None:
            print("Original Price:")
            f=c.execute("select bookname,price from add_books  where bookname= '" + title + "' ")
            for z in f:
                print(z)
            print("Discount Price:")
            query1="select bookname,price-discount from add_books  where bookname= '" + title + "' "
            x=c.execute(query1)
            for y in x:
                print(y)
    else:
        print("+++++++++++DISCOUNT NOT AVAILABLE++++++++++++")