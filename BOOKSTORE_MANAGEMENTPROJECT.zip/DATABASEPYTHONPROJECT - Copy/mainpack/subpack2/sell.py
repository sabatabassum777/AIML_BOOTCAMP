import sqlite3
conn=sqlite3.connect('Bookstore.db')
c=conn.cursor()#get result

def sell():
    title = str(input("Enter book name:"))
    quantity = int(input("Enter quantity:"))
    c.execute("select quantity from add_books where bookname='" + title + "'")
    log = c.fetchone()
    if log is not None:
        c.execute("insert into sell_books values('" + title + "','" + str(quantity) + "')")
        c.execute("update add_books set quantity=quantity-'" + str(quantity) + "' where bookname='" + title + "'")
        conn.commit()
        print("""++++++++++++++++++++++++BOOK HAS BEEN SOLD++++++++++++++++++++++++""")
    else:
        print("+++++++++++BOOKS NOT AVAILABLE++++++++++++++++++++++")

conn.commit()
