def mainpackdemo():
    return "WELCOME TO ONLINE BOOKSTORE "