import sqlite3
conn=sqlite3.connect('Bootcamp1.db')

conn.execute("insert into attendance values(2216101,'Yash Bollepally',98)")
conn.execute("insert into attendance values(2216102,'Chennamaneni Akshay Rao',97)")
conn.execute("insert into attendance values(2216103,'Ram Charan Teja',96)")
conn.execute("insert into attendance values(2216104,'Kandula Surya Kumari',96)")
conn.commit()
conn.close()