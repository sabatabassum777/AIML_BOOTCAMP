import sqlite3
conn=sqlite3.connect('Bootcamp1.db')
query=''' update attendance set name='Yashwanth' where g_id=2216101
'''
conn.execute(query)
print(conn.total_changes)
conn.commit()
conn.close()