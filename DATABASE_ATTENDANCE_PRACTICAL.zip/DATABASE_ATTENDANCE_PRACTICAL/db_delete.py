import sqlite3
conn=sqlite3.connect("Bootcamp1.db")
query= ''' delete from attendance where g_id=2216101
'''
conn.execute(query)
print(conn.total_changes)
conn.commit()
conn.close()

import sqlite3
conn=sqlite3.connect("Bootcamp1.db")
conn.execute("drop table attendance")