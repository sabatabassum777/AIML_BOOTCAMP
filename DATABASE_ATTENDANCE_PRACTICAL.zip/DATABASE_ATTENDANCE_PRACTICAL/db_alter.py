import sqlite3
conn=sqlite3.connect('Bootcamp1.db')#creating database
query=''' 
alter table attendance add column percentage int  not null 
'''
conn.execute(query)
conn.commit()
conn.close()