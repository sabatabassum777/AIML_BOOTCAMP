import sqlite3
conn=sqlite3.connect('Bootcamp1.db')
query=''' 
create table attendance(G_id int primary key, name text not null,percentage int not null)
'''
conn.execute(query)
conn.commit()
conn.close()